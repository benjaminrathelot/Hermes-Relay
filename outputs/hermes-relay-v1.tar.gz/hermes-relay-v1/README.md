# Hermes Relay

Hermes Relay is an offline-first, crisis-resilient messaging protocol and portable C implementation for very short end-to-end encrypted messages that can propagate through degraded environments.

The design assumptions are strict:

- one sender
- one recipient
- short text only
- no groups
- no attachments
- no central service
- no global consensus
- no delivery guarantee
- store-carry-forward forwarding between opportunistic peers

The implementation in this repository provides:

- a canonical binary envelope format
- an OpenSSL-backed cryptographic backend using one interoperable suite
- a defensive parser and serializer
- a flat-file store with deduplication markers and quota enforcement
- file bundle import and export
- LAN TCP inventory sync
- a CLI tool
- a propagation simulator
- unit tests
- a parser fuzz harness
- a CMake build description
- an integrated relay node package with a persistent peer addressbook
- a platform abstraction layer that keeps protocol and relay logic OS-independent

## Safety Notes

The C core is written as a length-explicit parser and serializer. The repository also includes build-time hardening:

- strict size limits for plaintext, payloads, reserved fields, frames, and envelopes
- canonical parse paths with exact-length checks
- no implicit trust in transport metadata
- no raw network-struct serialization or host-endian wire encoding
- optional AddressSanitizer and UndefinedBehaviorSanitizer builds
- compiler hardening flags enabled by default in CMake

## Portability Model

The codebase is split as:

- `core`: protocol, crypto abstraction, envelope handling, store, relay policy, sync
- `platform API`: narrow OS boundary for sockets, files, directories, service control, and process state
- `platform backend`: POSIX implementation for Linux, macOS, and Android-style targets, plus a Win32 implementation for Windows

That keeps the protocol and canonical envelope format stable across OS targets.

## Repository Layout

- `docs/protocol-spec.md`: normative wire-format specification
- `docs/threat-model.md`: system and adversary analysis
- `docs/architecture.md`: implementation architecture
- `docs/operator-quickstart.md`: first-use and first-deployment walkthrough
- `docs/cli-guide.md`: command reference and operator workflows
- `docs/python-wrapper.md`: desktop-oriented Python wrapper architecture
- `docs/desktop-shell.md`: local web UI and desktop shell model
- `docs/desktop-packaging.md`: packaged desktop app direction
- `docs/emergency-relay-playbook.md`: relay topologies and crisis operator guidance
- `docs/relay-node.md`: integrated relay node package and operations
- `docs/service-operations.md`: service runtime, recovery, and deployment guidance
- `docs/storage-and-relay-policy.md`: relay policy and quota rationale
- `docs/simulator-and-operations.md`: simulator model and deployment notes
- `include/hermes/`: public C headers
- `src/`: library and CLI implementation
- `python/`: Python wrapper, local web shell, and optional pywebview desktop launcher
- `tests/`: unit tests
- `fuzz/`: fuzz harnesses
- `scripts/build.sh`: direct build helper for environments without CMake in `PATH`
- `scripts/package.sh`: package assembly helper
- `packaging/`: Linux and macOS service assets plus a Windows wrapper template

## Interoperable Crypto Suite

Hermes Relay V1 fixes one suite for interoperability:

- signatures: Ed25519
- recipient encryption: X25519 + HKDF-SHA256 + ChaCha20-Poly1305
- hashing: SHA-256
- proof-of-work hash: SHA-256

This repository uses OpenSSL 3 EVP APIs as the active backend. The wire format is backend-neutral so a libsodium backend can be added without changing protocol bytes.

## PoW Policy

The sender-computed PoW must remain predictable across disconnected relays. This repository therefore uses a fixed relay acceptance threshold by default rather than raising the required difficulty dynamically when a later relay is under storage pressure.

The current repository default is `28` leading zero bits. That is a deployment policy constant, not a timing guarantee. Actual solve time depends on hardware.

## Build

Preferred:

```sh
cmake -S . -B build
cmake --build build
ctest --test-dir build
```

Fallback for minimal macOS environments where CMake is not installed in `PATH`:

```sh
./scripts/build.sh
./build/hermes-test
```

The direct build helper expects OpenSSL 3 under Homebrew at `/opt/homebrew/opt/openssl@3`.

## CLI Overview

The CLI has built-in contextual help:

```sh
./build/hermes-cli --help
./build/hermes-cli help create
./build/hermes-cli relay-run --help
```

For operator-oriented walkthroughs, read:

- `docs/operator-quickstart.md`
- `docs/cli-guide.md`
- `docs/python-wrapper.md`
- `docs/desktop-shell.md`
- `docs/emergency-relay-playbook.md`
- `docs/relay-node.md`
- `docs/service-operations.md`

Examples:

```sh
./build/hermes-cli genid --identity alice.id --alias alice
./build/hermes-cli export-contact --identity alice.id --out alice.contact
./build/hermes-cli genid --identity bob.id --alias bob
./build/hermes-cli export-contact --identity bob.id --out bob.contact
./build/hermes-cli create --identity alice.id --contact bob.contact --store ./alice-store --message "Meet at well 18:00" --out msg.bin
./build/hermes-cli verify --envelope msg.bin
./build/hermes-cli import-bundle --store ./bob-store --in relay.bundle
./build/hermes-cli decrypt --identity bob.id --envelope msg.bin
./build/hermes-cli serve --store ./relay-store --listen 0.0.0.0:9440
./build/hermes-cli sync --store ./relay-store --peer 192.168.1.8:9440
./build/hermes-cli stats --store ./relay-store
./build/hermes-cli cleanup --store ./relay-store
```

Integrated relay node:

```sh
./build/hermes-cli relay-init --root ./relay-a --listen 0.0.0.0:9440
./build/hermes-cli relay-add-peer --root ./relay-a --peer 192.168.1.44:9440 --alias neighbor
./build/hermes-cli relay-run --root ./relay-a
./build/hermes-cli relay-status --root ./relay-a
```

The integrated relay maintains a local peer addressbook, can auto-learn peers after successful relay handshakes, marks repeatedly failing peers inactive instead of deleting them immediately, writes structured rotated service logs, publishes a heartbeat status file, and can propagate new traffic immediately with `sync_on_change=1`.

## Status

This repository is a complete V1 engineering baseline rather than a polished end-user product. The protocol, parser, crypto, store, relay policy, simulator, CLI, and platform abstraction are implemented with portability and auditability prioritized over UX.
